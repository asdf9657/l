import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Item {
    int weight;
    int value;
    double valuePerWeight;

    public Item(int weight, int value) {
        this.weight = weight;
        this.value = value;
        this.valuePerWeight = (double) value / weight;
    }
}

public class FractionalKnapsack {
    public static double fractionalKnapsack(int capacity, List<Item> items) {
        // Sort items by value per weight in descending order
        Collections.sort(items, new Comparator<Item>() {
            @Override
            public int compare(Item item1, Item item2) {
                return Double.compare(item2.valuePerWeight, item1.valuePerWeight);
            }
        });

        double maxValue = 0.0;
        double currentWeight = 0.0;

        for (Item item : items) {
            if (currentWeight + item.weight <= capacity) {
                // Take the whole item
                currentWeight += item.weight;
                maxValue += item.value;
            } else {
                // Take a fraction of the item to fill the knapsack
                double remainingCapacity = capacity - currentWeight;
                maxValue += item.valuePerWeight * remainingCapacity;
                break;
            }
        }

        return maxValue;
    }

    public static void main(String[] args) {
        List<Item> items = new ArrayList<>();
        items.add(new Item(10, 60));
        items.add(new Item(20, 100));
        items.add(new Item(30, 120));

        int capacity = 50;
        double maxValue = fractionalKnapsack(capacity, items);

        System.out.println("Maximum value that can be obtained: " + maxValue);
    }
}
