#Non-Recursive (Iterative) Approach:
def fibonacci_iterative(n):
    if n <= 1:
        return n
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
        print("Fibonacci sequence Non-Recursive (Iterative) Approach:",b)
    return b
n = 5
result = fibonacci_iterative(n)
print( result)

